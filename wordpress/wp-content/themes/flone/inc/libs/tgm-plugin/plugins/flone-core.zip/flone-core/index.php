<?php
// Silence is golden